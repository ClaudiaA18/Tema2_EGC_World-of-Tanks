#pragma once

#include "lab_m1\Tema2\Tema2.h"